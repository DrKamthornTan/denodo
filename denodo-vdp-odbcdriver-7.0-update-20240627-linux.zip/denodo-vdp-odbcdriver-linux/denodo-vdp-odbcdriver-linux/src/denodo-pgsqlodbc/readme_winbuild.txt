This folder contains 2 batch scripts
	BuildAll.bat
	editConfiguration.bat
which have the same functionalities as corresponding powershell scripts in
winbuild folder.

See docs\win32-compilation.html and winbuild\readme.txt for Windows compilation instructions.

For info on building installers, see installer\README.txt
