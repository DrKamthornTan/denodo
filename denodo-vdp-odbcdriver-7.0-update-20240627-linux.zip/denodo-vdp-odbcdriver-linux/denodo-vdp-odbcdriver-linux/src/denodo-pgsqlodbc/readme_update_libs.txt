@@ -0,0 +1,178 @@
HOW TO UPDATE DENODOODBC DEPENDAND LIBRARIES:
	- UPDATE OPENSSL (For 1.1.x versions) 
	- PATCH & UPDATE LIBPQ

------------------------------------------------------------------------------------------ PREP

0a. Install x86 OpenSSL: $OpenSSL32 = E:\OpenSSL-Win32
0b. Install x64 OpenSSL: $OpenSSL32 = E:\OpenSSL-Win64
0c. Install x86 GetText: $GetText32 = E:\GetText\gettext0.20.1-iconv1.16-shared-32
0d. Install x64 GetText: $GetText64 = E:\GetText\gettext0.20.1-iconv1.16-shared-64
0e. Unzip Kerberos at C:\kfw-2.6.5
0f. Uncompress postgreSQL source code: $Postgre = E:/git_external/postgresql
0g. Uncompress curl source code: $LibCurl = C:\libcurl\curl-7.72.0

------------------------------------------------------------------------------------------ 32 BIT 

1. Clean&Create following folders:
	C:\PostgreSQL Libraries\32bits
		- bin
		- include
		- lib
	
2. Copy into C:/PostgreSQL Libraries/32bits/bin:
	- $GetText32/bin/libint.dll (it probably appears as libint-8.dll, renameit)
	- $OpenSSL32/libcrypto-1_1.dll
	- $OpenSSL32/libssl-1_1.dll

3. Copy into C:/PostgreSQL Libraries/32bits/include
	- $OpenSSL32/include/openssl/ (openssl folder should exist inside include folder)
	- $Postgre/src/include/pg_config_ext.h
	- $Postgre/src/include/postgres_ext.h
	- $Postgre/src/interfaces/libpq/*.h
	
4. Copy into C:/PostgreSQL Libraries/32bits/lib
	- $OpenSSL32/lib/libcrypto.lib
	- $OpenSSL32/lib/VC/libcrypto32MD.lib
	- $OpenSSL32/lib/libssl.lib
	- $OpenSSL32/lib/VC/libssl32MD.lib
	
5. Configure LibPQ for compile (skip these if its already done)
	- Delete $Postgre/src/interfaces/libpq/Release
	- Edit $Postgre/src/interfaces/libpq/win32.mak
		- Add these flags at the very beggining
			ENABLE_THREAD_SAFETY=1
			USE_OPENSSL=1
			USE_KFW=1		
		- Remove bufferoverflowU.lib from the ADD_SECLIB variable
		- Comment with # the manifest line:
			# mt -manifest $(OUTDIR)\$(OUTFILENAME).dll.manifest -outputresource:$(OUTDIR)\$(OUTFILENAME).dll;2					
	- Apply (manually) the open patch to enable open delegation: <GIT_denodo-pgsqlodbc>/libpq.patch to fe-auth.c file
		- this fe-auth.c may have changed in your new postgresql version, if so please take neccessary steps to update libpq.path is used in Linux process

6. Compile LibPQ
	- Delete $Postgre/src/interfaces/libpq/Release
	- Compile (Used literal commands here with absolute paths, adapt them if necessary) Open CMD at $Postgre
		$> cd src
		$> "C:\Program Files (x86)\Microsoft Visual Studio 10.0\VC\vcvarsall.bat" x86
		$> nmake /f win32.mak CPU=i386 SSL_INC="C:\PostgreSQL Libraries\32bits\include" SSL_LIB_PATH="C:\PostgreSQL Libraries\32bits\lib"
		
7. Copy into C:/PostgreSQL Libraries/32bits/lib
	- $Postgre/src/interfaces/libpq/Release/libpqdll.lib
	- Rename it to libpq.lib
	
8. Copy into C:/PostgreSQL Libraries/32bits/bin
	- $Postgre/src/interfaces/libpq/Release/libpq.dll

9. Compile LibCurl	
	- Delete $LibCurl/builds
	- Compile (Used literal commands here with absolute paths, adapt them if necessary) Open CMD at $LibCurl
		$> cd winbuild
		$> "C:\Program Files (x86)\Microsoft Visual Studio 10.0\VC\vcvarsall.bat" x86
		$> nmake /f Makefile.vc mode=dll VC=10 WITH_SSL=dll WITH_DEVEL="C:\PostgreSQL Libraries\32bits" MACHINE=x86

10. Copy into C:/PostgreSQL Libraries/32bits/bin
	- $LibCurl/builds/libcurl-vc10-x86-release-dll-ssl-dll-ipv6-sspi/bin/libcurl.dll
	
11. Copy into C:/PostgreSQL Libraries/32bits/include
	- $LibCurl/builds/libcurl-vc10-x86-release-dll-ssl-dll-ipv6-sspi/include (copy the entire folder).
	
12. Copy into C:/PostgreSQL Libraries/32bits/lib	
	- $LibCurl/builds/libcurl-vc10-x86-release-dll-ssl-dll-ipv6-sspi/lib/libcurl.lib 

------------------------------------------------------------------------------------------ 64 BIT

1. Clean&Create following folders:
	C:\PostgreSQL Libraries\64bits
		- bin
		- include
		- lib
		
2. Copy into C:/PostgreSQL Libraries/64bits/bin:
	- $GetText64/bin/libint-8.dll
	- $OpenSSL64/libcrypto-1_1-x64.dll
	- $OpenSSL64/libssl-1_1-x64.dll

3. Copy into C:/PostgreSQL Libraries/64bits/include
	- $OpenSSL64/include/openssl/ (openssl folder should exist inside include folder)
	- $Postgre/src/include/pg_config_ext.h
	- $Postgre/src/include/postgres_ext.h
	- $Postgre/src/interfaces/libpq/*.h

4. Copy into C:/PostgreSQL Libraries/64bits/lib
	- $OpenSSL64/lib/libcrypto.lib
	- $OpenSSL64/lib/VC/libcrypto64MD.lib
	- $OpenSSL64/lib/libssl.lib
	- $OpenSSL64/lib/VC/libssl64MD.lib

5. Configure LibPQ for compile (skip these if its already done)
	- Delete $Postgre/src/interfaces/libpq/Release
	- Edit $Postgre/src/interfaces/libpq/win32.mak
		- Add these flags at the very beggining
			ENABLE_THREAD_SAFETY=1
			USE_OPENSSL=1
			USE_KFW=1		
		- Remove bufferoverflowU.lib from the ADD_SECLIB variable
		- Comment with # the manifest line:
			# mt -manifest $(OUTDIR)\$(OUTFILENAME).dll.manifest -outputresource:$(OUTDIR)\$(OUTFILENAME).dll;2					
	- Apply (manually) the open patch to enable open delegation: <GIT_denodo-pgsqlodbc>/libpq.patch to fe-auth.c file
		- this fe-auth.c may have changed in your new postgresql version, if so please take neccessary steps to update libpq.path is used in Linux process

6. Compile LibPQ
	- Delete $Postgre/src/interfaces/libpq/Release
	- Compile (Used literal commands here with absolute paths, adapt them if necessary) Open CMD at $Postgre
		$> cd src
		$> "C:\Program Files (x86)\Microsoft Visual Studio 10.0\VC\vcvarsall.bat" x64
		$> nmake /f win32.mak CPU=AMD64 SSL_INC="C:\PostgreSQL Libraries\64bits\include" SSL_LIB_PATH="C:\PostgreSQL Libraries\64bits\lib"

7. Copy into C:/PostgreSQL Libraries/64bits/lib
	- $Postgre/src/interfaces/libpq/Release/libpqdll.lib
	- Renombrarlo a libpq.lib
	
8. Copy into C:/PostgreSQL Libraries/64bits/bin
	- $Postgre/src/interfaces/libpq/Release/libpq.dll

9. Compile LibCurl	
	- Delete $LibCurl/builds
	- Compile (Used literal commands here with absolute paths, adapt them if necessary) Open CMD at $LibCurl
		$> cd winbuild
		$> "C:\Program Files (x86)\Microsoft Visual Studio 10.0\VC\vcvarsall.bat" x64
		$> nmake /f Makefile.vc mode=dll VC=10 WITH_SSL=dll WITH_DEVEL="C:\PostgreSQL Libraries\64bits" MACHINE=x64

10. Copy into C:/PostgreSQL Libraries/64bits/bin
	- $LibCurl/builds/libcurl-vc10-x64-release-dll-ssl-dll-ipv6-sspi/bin/libcurl.dll
	
11. Copy into C:/PostgreSQL Libraries/64bits/include
	- $LibCurl/builds/libcurl-vc10-x64-release-dll-ssl-dll-ipv6-sspi/include (copy the entire folder).
	
12. Copy into C:/PostgreSQL Libraries/64bits/lib	
	- $LibCurl/builds/libcurl-vc10-x64-release-dll-ssl-dll-ipv6-sspi/lib/libcurl.lib 
	
------------------------------------------------------------------------------------------ NOTES

DenodoODBC dependency routes	
	C:/PostgreSQL Libraries/64bits
	C:/PostgreSQL Libraries/32bits
will be now updated adn ready to compile the DenodoODBC driver


OpenSSL used it was downloaded from: https://slproweb.com/products/Win32OpenSSL.html
	- The kickback is that this version depends on VS2014 runtime library, while Denodo and LibPQ will depend on VS2010 as that is the compiler we have
	- Future enh: improve these steps to also Compile OpenSSL

LibCurl used it was downloaded from: https://curl.se/download.html
